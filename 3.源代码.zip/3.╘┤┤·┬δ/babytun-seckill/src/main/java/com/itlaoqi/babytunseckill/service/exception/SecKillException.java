package com.itlaoqi.babytunseckill.service.exception;

public class SecKillException extends Exception{
    public SecKillException(String msg){
        super(msg);
    }
}
