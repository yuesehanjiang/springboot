package com.itlaoqi.seckillsample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeckillSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeckillSampleApplication.class, args);
	}
}
