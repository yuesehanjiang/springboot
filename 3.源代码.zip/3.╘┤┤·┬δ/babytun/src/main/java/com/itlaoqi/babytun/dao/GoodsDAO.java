package com.itlaoqi.babytun.dao;

import com.itlaoqi.babytun.entity.Goods;

public interface GoodsDAO {
    public Goods findById(Long goodsId);
}
